// One-time migration: pulls data from the OLD storage (Vercel Blob +
// Google Apps Script sheet, or a local CSV for beatmaps) and writes it
// into the NEW Supabase project.
//
// Usage:
//   1. npm install @vercel/blob --no-save   (temporary, only needed to run this script)
//   2. Copy scripts/.env.migrate.example -> scripts/.env.migrate and fill it in
//   3. node --env-file=scripts/.env.migrate scripts/migrate-to-supabase.mjs
//
// Safe to re-run: files/shortlinks use upsert (won't duplicate), messages
// are skipped if an identical (message + created_at) row already exists.

import { list, head } from '@vercel/blob';
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const {
  OLD_BLOB_READ_WRITE_TOKEN,
  OLD_CONTACT_MESSAGES_FEED_URL,
  OLD_BEATMAP_FEED_URL,
  OLD_BEATMAP_CSV_PATH,
  SUPABASE_URL,
  SUPABASE_SERVICE_ROLE_KEY,
} = process.env;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('Missing SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY. See scripts/.env.migrate.example.');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});
const VAULT_BUCKET = 'vault';

async function migrateFiles() {
  if (!OLD_BLOB_READ_WRITE_TOKEN) {
    console.log('⏭️  Skipping files: OLD_BLOB_READ_WRITE_TOKEN not set.');
    return;
  }

  console.log('\n📁 Migrating vault files...');
  let cursor;
  let migrated = 0;
  let failed = 0;

  do {
    const page = await list({ prefix: 'v/', cursor, token: OLD_BLOB_READ_WRITE_TOKEN });
    for (const blob of page.blobs) {
      try {
        const res = await fetch(blob.url);
        if (!res.ok) throw new Error(`download failed (${res.status})`);
        const bytes = new Uint8Array(await res.arrayBuffer());

        const { error } = await supabase.storage.from(VAULT_BUCKET).upload(blob.pathname, bytes, {
          contentType: res.headers.get('content-type') || 'application/octet-stream',
          upsert: true,
        });
        if (error) throw error;

        migrated += 1;
        console.log(`  ✓ ${blob.pathname} (${(blob.size / 1024).toFixed(1)} KB)`);
      } catch (err) {
        failed += 1;
        console.error(`  ✗ ${blob.pathname}:`, err instanceof Error ? err.message : err);
      }
    }
    cursor = page.cursor;
  } while (cursor);

  console.log(`📁 Files done: ${migrated} migrated, ${failed} failed.`);
}

async function migrateShortlinks() {
  if (!OLD_BLOB_READ_WRITE_TOKEN) {
    console.log('⏭️  Skipping shortlinks: OLD_BLOB_READ_WRITE_TOKEN not set.');
    return;
  }

  console.log('\n🔗 Migrating short links...');
  try {
    const meta = await head('shortlinks/index.json', { token: OLD_BLOB_READ_WRITE_TOKEN });
    const res = await fetch(meta.url, { cache: 'no-store' });
    const data = await res.json();
    const links = Array.isArray(data) ? data : [];

    if (links.length === 0) {
      console.log('🔗 No short links found in the old index.');
      return;
    }

    const rows = links.map(l => ({
      slug: l.slug,
      url: l.url,
      clicks: l.clicks || 0,
      created_at: l.createdAt || new Date().toISOString(),
    }));

    const { error } = await supabase.from('shortlinks').upsert(rows, { onConflict: 'slug' });
    if (error) throw error;

    console.log(`🔗 Short links done: ${rows.length} migrated.`);
  } catch (err) {
    console.log('🔗 No existing short link index found (or failed to read it) — nothing to migrate.');
    console.error('   ', err instanceof Error ? err.message : err);
  }
}

function pick(row, keys) {
  for (const key of Object.keys(row)) {
    if (keys.includes(key.toLowerCase().trim())) {
      const value = row[key];
      if (value !== null && value !== undefined && value !== '') return String(value);
    }
  }
  return '';
}

async function migrateMessages() {
  if (!OLD_CONTACT_MESSAGES_FEED_URL) {
    console.log('⏭️  Skipping messages: OLD_CONTACT_MESSAGES_FEED_URL not set.');
    return;
  }

  console.log('\n✉️  Migrating contact messages...');
  const ANON_EMAIL = 'anonymous@antipole.my.id';

  const res = await fetch(OLD_CONTACT_MESSAGES_FEED_URL, { cache: 'no-store' });
  const data = await res.json();
  const rows = Array.isArray(data)
    ? data
    : Array.isArray(data?.messages)
    ? data.messages
    : Array.isArray(data?.rows)
    ? data.rows
    : [];

  // Existing rows already in Supabase, so a re-run doesn't duplicate them.
  const { data: existing } = await supabase.from('messages').select('message, created_at');
  const existingKeys = new Set((existing || []).map(r => `${r.message}::${r.created_at}`));

  let migrated = 0;
  let skipped = 0;

  for (const row of rows) {
    const name = pick(row, ['name', 'nama']) || 'Unknown';
    const emailRaw = pick(row, ['email', 'e-mail']);
    const message = pick(row, ['message', 'pesan', 'msg', 'comment']);
    const timestampRaw = pick(row, ['timestamp', 'date', 'time', 'waktu', 'tanggal']);
    if (!message) continue;

    const isAnonymous = emailRaw.toLowerCase() === ANON_EMAIL || !emailRaw;
    const email = isAnonymous ? ANON_EMAIL : emailRaw;

    let createdAt = new Date().toISOString();
    if (timestampRaw) {
      const parsed = new Date(timestampRaw);
      createdAt = Number.isNaN(parsed.getTime()) ? createdAt : parsed.toISOString();
    }

    const key = `${message}::${createdAt}`;
    if (existingKeys.has(key)) {
      skipped += 1;
      continue;
    }

    const { error } = await supabase.from('messages').insert({
      name,
      email,
      message,
      is_anonymous: isAnonymous,
      created_at: createdAt,
    });
    if (error) {
      console.error('  ✗ insert failed:', error.message);
      continue;
    }
    existingKeys.add(key);
    migrated += 1;
  }

  console.log(`✉️  Messages done: ${migrated} migrated, ${skipped} already present.`);
}

// Minimal RFC4180 CSV parser (handles quoted fields, embedded commas,
// escaped "" quotes) — no external dependency needed for a one-off script.
function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  const pushField = () => { row.push(field); field = ''; };
  const pushRow = () => { rows.push(row); row = []; };

  const src = text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');

  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      pushField();
    } else if (ch === '\n') {
      pushField();
      pushRow();
    } else {
      field += ch;
    }
  }
  if (field.length > 0 || row.length > 0) {
    pushField();
    pushRow();
  }

  const dataRows = rows.filter(r => r.some(cell => cell.trim() !== ''));
  if (dataRows.length === 0) return [];

  const headers = dataRows[0].map(h => h.trim().toLowerCase());
  return dataRows.slice(1).map(r => {
    const obj = {};
    headers.forEach((h, idx) => { obj[h] = (r[idx] ?? '').trim(); });
    return obj;
  });
}

function pickCsv(row, keys) {
  for (const key of Object.keys(row)) {
    if (keys.includes(key) && row[key]) return row[key];
  }
  return '';
}

async function migrateBeatmaps() {
  let rows = [];

  if (OLD_BEATMAP_CSV_PATH) {
    console.log(`\n🎵 Migrating contributed beatmaps from CSV: ${OLD_BEATMAP_CSV_PATH}`);
    const text = readFileSync(resolve(OLD_BEATMAP_CSV_PATH), 'utf8');
    rows = parseCsv(text).map(r => ({
      link: pickCsv(r, ['link', 'url', 'beatmap link', 'beatmapset', 'beatmapset link']),
      title: pickCsv(r, ['title', 'song', 'name']),
      artist: pickCsv(r, ['artist']),
      // Badges in one cell, separated by comma (or | / ;) — e.g. "Ranked, Loved".
      badges: pickCsv(r, ['badges', 'tags', 'status'])
        .split(/[|,;]/)
        .map(b => b.trim())
        .filter(Boolean),
      lastUpdated: pickCsv(r, ['last_updated', 'last updated', 'updated', 'updated_at', 'date']),
    }));
  } else if (OLD_BEATMAP_FEED_URL) {
    console.log('\n🎵 Migrating contributed beatmaps from feed URL...');
    const res = await fetch(OLD_BEATMAP_FEED_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error(`Beatmap feed fetch failed (${res.status})`);
    const data = await res.json();
    rows = Array.isArray(data) ? data : [];
  } else {
    console.log('⏭️  Skipping beatmaps: neither OLD_BEATMAP_CSV_PATH nor OLD_BEATMAP_FEED_URL is set.');
    return;
  }

  rows = rows.filter(r => r && typeof r.link === 'string' && r.link.trim());

  if (rows.length === 0) {
    console.log('🎵 No beatmaps found in the source.');
    return;
  }

  // Existing links already in Supabase, so a re-run doesn't duplicate them.
  const { data: existing } = await supabase.from('beatmaps').select('link');
  const existingLinks = new Set((existing || []).map(r => r.link));

  const toInsert = rows
    .filter(r => !existingLinks.has(r.link.trim()))
    .map(r => {
      const parsed = r.lastUpdated ? new Date(r.lastUpdated) : null;
      const lastUpdated = parsed && !Number.isNaN(parsed.getTime()) ? parsed.toISOString() : new Date().toISOString();
      return {
        link: r.link.trim(),
        title: r.title || '',
        artist: r.artist || '',
        badges: Array.isArray(r.badges) ? r.badges : [],
        last_updated: lastUpdated,
      };
    });

  let migrated = 0;
  if (toInsert.length > 0) {
    const { error } = await supabase.from('beatmaps').insert(toInsert);
    if (error) throw error;
    migrated = toInsert.length;
  }

  console.log(`🎵 Beatmaps done: ${migrated} migrated, ${rows.length - migrated} already present/skipped.`);
}

async function main() {
  console.log('Starting migration to Supabase...');
  await migrateFiles();
  await migrateShortlinks();
  await migrateMessages();
  await migrateBeatmaps();
  console.log('\n✅ Migration finished.');
}

main().catch(err => {
  console.error('\n❌ Migration failed:', err);
  process.exit(1);
});
